<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../public/admin/vendors/feather/feather.css">
  <link rel="stylesheet" href="../public/admin/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="../public/admin/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="../public/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="../public/admin/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" type="text/css" href="../public/admin/js/select.dataTables.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../public/admin/css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../public/admin/images/favicon.png" />
  <style>
       .delete{
       padding: 5px;
        background-color:red;
        color:white;
        border-radius:10px;
      }
      .edit{
       padding: 5px 10px;
       
        background-color:blue;
        color:white;
        border-radius:10px;
      }
      a:hover {
        color:white;
      }   
      
  </style>
  
</head>